# Minecraft-Auto-AFK
Minecraft functions to mark a player as AFK when not moving.

To install:
1) Copy the auto-afk.zip minecraft world under /world/datapacks/
2) Restart the world or execute /reload.

To remove, execute the afk.uninstall function.
